package gov.nist.policyserver.requests;

public class AddOperationsToProhibitionRequest {
    String[] operations;
    public String[] getOperations(){
        return operations;
    }
}
