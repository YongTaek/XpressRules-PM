package gov.nist.policyserver.requests;

public class SetIntervalRequest {
    int interval;

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }
}
